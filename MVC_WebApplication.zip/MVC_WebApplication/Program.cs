

var builder = WebApplication.CreateBuilder(args);
// Add services to the container.
builder.Services.AddControllersWithViews();

builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(option =>
{
    option.IdleTimeout = TimeSpan.FromMinutes(1);
    //(below) Under-Development:
    option.Cookie.HttpOnly = true;
    option.Cookie.IsEssential = true;
});

var app = builder.Build();
//Startup.cs - Debug
/**/

/**/
// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}
app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseSession();



app.UseAuthorization();

/*app.MapControllerRoute(
    name: "connection",
    pattern: "Ctrl_Player/{*Create_PlayerData}",
    defaults: "{controller=Ctrl_Player}/{action=Create_PlayerData}/{status?}"
    );*/

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Ctrl_User}/{action=Login}/{id?}"); //previous: controller=Home



app.Run();
