﻿namespace MVC_WebApplication.Models
{
    public class Model_TeamRoster
    {
        public int Team_id { get; set; }
        public string? Team_name { get; set; }
        public int Player_num { get; set; } //Bug-fix ... 'player_num' not relevant;
        public string? Player_name { get; set; }
        public string? Player_pos { get; set; }
        public int GP { get; set; }
        public int PTS { get; set; }
        public int REB { get; set; }
        public int AST { get; set; }
        public int BLK { get; set; }
        public int STL { get; set; }
    }
}
