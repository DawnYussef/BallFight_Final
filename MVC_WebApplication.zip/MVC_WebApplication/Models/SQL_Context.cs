﻿using MySql.Data.MySqlClient;
using MVC_WebApplication.Models;
using System;
using System.Collections.Generic;

namespace MVC_WebApplication.Models
{
    public class SQL_Context
    {
        public string ConnectionString { get; set; }
        public SQL_Context(string conSQL_String)
        {
            this.ConnectionString = conSQL_String;
        }
        private MySqlConnection InitConnection()
        {
            return new MySqlConnection(ConnectionString);
        }

        
        //[DEVELOP] - 'admin' permissions to access;
        public List<Model_User> Admin_listUsers()
        {
            List<Model_User> listUser = new List<Model_User>();

            using (MySqlConnection conSQL = InitConnection())
            {
                conSQL.Open();
                MySqlCommand cmndSQL = new MySqlCommand("select * from userdata;", conSQL);

                using (var qrd = cmndSQL.ExecuteReader())
                {
                    while (qrd.Read())
                    {
                        listUser.Add(new Model_User()
                        {
                            // id = Convert.ToInt32(reader["user_id"]),
                            Username = qrd["Username"].ToString(),
                            Email = qrd["Email"].ToString(),
                            //password = reader["password"].ToString()
                        });
                    }
                }

                conSQL.Close();
            }

            return listUser;
        }

        public bool User_Registration(string username, string email, string password)
        {
            using (MySqlConnection conSQL = InitConnection())
            {
                try
                {
                    conSQL.Open();
                    MySqlCommand command = new MySqlCommand("insert into userdata(username, email, password) values(@val1, @val2, sha1(@val3));", conSQL);
                    command.Parameters.AddWithValue("@val1", username);
                    command.Parameters.AddWithValue("@val2", email);
                    command.Parameters.AddWithValue("@val3", password);
                    command.Prepare();
                    command.ExecuteNonQuery();

                    return true;

                }
                catch (Exception ex)
                {
                    return false;
                }
                finally
                {
                    conSQL.Close();
                }
            }

            //return false; //Unreachable?
        }

        public Model_User Login(string email, string password)
        {


            using (MySqlConnection conSQL = InitConnection())
            {
                try
                {
                    conSQL.Open();
                    MySqlCommand cmndSQL = new MySqlCommand("SELECT * FROM userdata WHERE Email=@email AND Password =sha1(@password) limit 1;", conSQL);
                    cmndSQL.Parameters.AddWithValue("@email", email);
                    cmndSQL.Parameters.AddWithValue("@password", password);

                    MySqlDataReader qrd = cmndSQL.ExecuteReader();
                    if (qrd.Read())
                    {
                        return new Model_User { User_id = int.Parse(qrd["User_id"].ToString()), Username = qrd["Username"].ToString(), Email = qrd["Email"].ToString(), Password = qrd["Password"].ToString() };
                    }

                }
                catch
                {

                }

                finally
                {
                    conSQL.Close();
                }
            }


            return null;
        }

        public List<Model_Team> DisplayTeams()
        {
            List<Model_Team> list_Team = new List<Model_Team>();
            
            using (MySqlConnection conSQL = InitConnection())
            {
                conSQL.Open();
                MySqlCommand cmndSQL = new MySqlCommand("SELECT * from TeamData", conSQL);
                using(var qrd = cmndSQL.ExecuteReader())
                {
                    while (qrd.Read())
                    {
                        list_Team.Add(new Model_Team()
                        {
                            Team_id = (int)qrd["Team_id"],
                            Team_name = qrd["Team_name"].ToString(),
                            Team_abr = qrd["Team_abr"].ToString(),
                            City = qrd["City"].ToString(),
                            US_State = qrd["US_State"].ToString(),
                            W = (int)qrd["W"],
                            L = (int)qrd["L"]
                        });
                    }
                }
            }
                return list_Team;
        }
        public List<Model_Player> DisplayPlayers()
        {
            List<Model_Player> list_Player = new List<Model_Player>();
            using(MySqlConnection conSQL = InitConnection())
            {
                conSQL.Open();
                MySqlCommand cmndSQL = new MySqlCommand("SELECT * from PlayerData;", conSQL);
                using(var qrd = cmndSQL.ExecuteReader())
                {
                    while (qrd.Read())
                    {
                        list_Player.Add(new Model_Player()
                        {
                            Player_id = (int)qrd["Player_id"],
                            Team_id = (int)qrd["Team_id"],
                            Player_num = (int)qrd["Player_num"],
                            Player_name = qrd["Player_name"].ToString(),
                            Player_pos = qrd["Player_pos"].ToString(),
                            PTS = (int)qrd["PTS"],//Point(total) - PTS
                            REB = (int)qrd["REB"],//Rebound - REB
                            AST = (int)qrd["AST"],//Assist - AST
                            BLK = (int)qrd["BLK"],//Block(s) - BLK
                            GP = (int)qrd["GP"],//Games Played - GP
                            FGM = (int)qrd["FGM"],//Field Goal(s) Made (2 PTS) - FGM
                            FGA = (int)qrd["FGA"],//Field Goal(s) Attempted - FGA
                            Three_PM = (int)qrd["Three_PM"],//3 PTS Made - 3PM
                            Three_PA = (int)qrd["Three_PA"],//3 PTS Attemped - 3PA
                            FTM = (int)qrd["FTM"],//Free-Throw(s) Made - FTM
                            FTA = (int)qrd["FTA"],//Free-Throw(s) Attempted - FTA
                            STL = (int)qrd["STL"],//Steal(s) - STL
                            PF = (int)qrd["PF"]//Personal Fouls - PF
                        });
                    }

                    conSQL.Close();
                }

                return list_Player;
            }
        }

        
        public List<Model_Comment> AcctContent_Compile(int userID)
        {
            List<Model_Comment> listComments = new List<Model_Comment>();

            using (MySqlConnection conSQL = InitConnection())
            {
                conSQL.Open();
                //MySqlCommand cmndSQL;
                if (userID != null)
                {
                    MySqlCommand cmndSQL = new MySqlCommand("select username, comments, likes, dislikes from content right join userdata using (user_id) where user_id =" + userID + ";", conSQL);

                    using (var qrd = cmndSQL.ExecuteReader())
                    {
                        while (qrd.Read())
                        {
                            listComments.Add(new Model_Comment()
                            {
                                
                                Comments = qrd["Comments"].ToString(),
                                Likes = (int)qrd["Likes"],
                                Dislikes = (int)qrd["Dislikes"]
                            });
                        }
                    }
                }
                /*else
                {
                    //Alert - Must login in to access Profile Features.
                    
                }*/

                conSQL.Close();
            }

            return listComments;
        }

        public List<Model_TeamRoster> TeamRoster_Compile(int team_id, string pos)
        {
            List<Model_TeamRoster> list_TeamRoster = new List<Model_TeamRoster>();

            using (MySqlConnection conSQL = InitConnection())
            {
                conSQL.Open();
                MySqlCommand cmndSQL;
                
                if (pos != null)
                {
                    cmndSQL = new MySqlCommand("SELECT team_id, team_name, player_num, player_name, player_pos, GP, PTS, REB, AST, BLK, STL FROM teamdata LEFT JOIN playerdata USING (team_id) WHERE team_id = " + team_id + " AND player_pos = '" + pos + "';", conSQL);
                }
                //SELECT team_id, team_name, player_num, player_name, player_pos, GP, PTS, REB, AST, BLK, STL FROM teamdata LEFT JOIN playerdata USING (team_id) WHERE team_id = 1 AND player_pos = 'C'; 

                else
                {
                    cmndSQL = new MySqlCommand("SELECT team_id, team_name, player_num, player_name, player_pos, GP, PTS, REB, AST, BLK, STL FROM teamdata LEFT JOIN playerdata USING (team_id) WHERE team_id = " + team_id + ";", conSQL);
                }
                //SELECT team_id, team_name, player_num, player_name, player_pos, GP, PTS, REB, AST, BLK, STL FROM teamdata LEFT JOIN playerdata USING (team_id) WHERE team_id = 1;
                using (var qrd = cmndSQL.ExecuteReader())
                {
                    while (qrd.Read())
                    {
                        list_TeamRoster.Add(new Model_TeamRoster()
                        {
                            Team_id = (int)qrd["Team_id"],
                            Team_name = qrd["Team_name"].ToString(),
                            Player_name = qrd["Player_name"].ToString(),
                            Player_pos = qrd["Player_pos"].ToString(),
                            GP = (int)qrd["GP"],
                            PTS = (int)qrd["PTS"],
                            REB = (int)qrd["REB"],
                            AST = (int)qrd["AST"],
                            BLK = (int)qrd["BLK"],
                            STL = (int)qrd["STL"]
                        });
                    }
                }

                conSQL.Close();
            }

            return list_TeamRoster;
        }
        
    }
}
