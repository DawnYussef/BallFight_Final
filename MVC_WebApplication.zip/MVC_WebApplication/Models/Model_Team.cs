﻿namespace MVC_WebApplication.Models
{
    public class Model_Team
    {
        public int Team_id { get; set; }
        public string? Team_name { get; set; }
        public string? Team_abr { get; set; }
        public string? City { get; set; }
        public string? US_State { get; set; }
        public int W { get; set; }
        public int L { get; set; }
    }
}
