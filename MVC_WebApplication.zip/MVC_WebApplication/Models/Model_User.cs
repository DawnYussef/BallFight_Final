﻿namespace MVC_WebApplication.Models
{
    public class Model_User
    {
        //private SQL_Context ctx;
        public int User_id { get; set; }

        public string? Username { get; set; }

        public string? Email { get; set; }

        public string? Password { get; set; }

        //public bool Adminstr { get; set; }
    }

}
