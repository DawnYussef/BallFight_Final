﻿namespace MVC_WebApplication.Models
{
    public class Model_Comment
    {
        public int Comment_id { get; set; }
        public int User_id { get; set; }
        public string? Comments { get; set; }
        public int Likes { get; set; }
        public int Dislikes { get; set; }
    }
}
