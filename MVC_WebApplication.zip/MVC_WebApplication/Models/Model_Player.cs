﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_WebApplication.Models
{
    public class Model_Player
    {
        public int Player_id { get; set; }
        public int Team_id { get; set; }
        public int Player_num { get; set; }
        public string? Player_name { get; set; }
        public string? Player_pos { get; set; }
        public int PTS { get; set; }
        public int REB { get; set; }
        public int AST { get; set; }
        public int BLK { get; set; }

        public int GP { get; set; }
        public int FGM { get; set; }
        public int FGA { get; set; }
        public int Three_PM { get; set; }
        public int Three_PA { get; set; }

        public int FTM { get; set; }
        public int FTA { get; set; }

        public int STL { get; set; }
        public int PF { get; set; }
    }
}