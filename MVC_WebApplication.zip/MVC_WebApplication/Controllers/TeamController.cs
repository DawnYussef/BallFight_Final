﻿using Microsoft.AspNetCore.Mvc;
using MVC_WebApplication.Models;

namespace MVC_WebApplication.Controllers
{
    public class TeamsController : Controller
    {
        public SQL_Context ctx = new SQL_Context(@"server=localhost;uid=root;password=Gen$park0;database=genspark_proj");
        public IActionResult LAL()
        {
            List<Model_Player> list = ctx.DisplayPlayers();
            return View(list);
        }
        public IActionResult GSW()
        {
            List<Model_Player> list = ctx.DisplayPlayers();
            return View(list);
        }
    }
}