﻿using Microsoft.AspNetCore.Mvc;
using MVC_WebApplication.Models;

namespace MVC_WebApplication.Controllers
{
    public class PlayersController : Controller
    {
        public SQL_Context ctx = new SQL_Context(@"server=localhost;uid=root;password=Gen$park0;database=genspark_proj");
        public IActionResult James()
        {
            List<Model_Player> list = ctx.DisplayPlayers();
            return View(list);
        }
        public IActionResult HortenTucker()
        {
            List<Model_Player> list = ctx.DisplayPlayers();
            return View(list);
        }
        public IActionResult Anthony()
        {
            List<Model_Player> list = ctx.DisplayPlayers();
            return View(list);
        }
        public IActionResult Westbrook()
        {
            List<Model_Player> list = ctx.DisplayPlayers();
            return View(list);
        }
        public IActionResult Davis()
        {
            List<Model_Player> list = ctx.DisplayPlayers();
            return View(list);
        }
        public IActionResult Curry()
        {
            List<Model_Player> list = ctx.DisplayPlayers();
            return View(list);
        }
        public IActionResult Poole()
        {
            List<Model_Player> list = ctx.DisplayPlayers();
            return View(list);
        }
        public IActionResult Wiggins()
        {
            List<Model_Player> list = ctx.DisplayPlayers();
            return View(list);
        }
        public IActionResult Green()
        {
            List<Model_Player> list = ctx.DisplayPlayers();
            return View(list);
        }
        public IActionResult Looney()
        {
            List<Model_Player> list = ctx.DisplayPlayers();
            return View(list);
        }
    }
}
