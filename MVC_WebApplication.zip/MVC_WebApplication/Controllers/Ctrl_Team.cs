﻿using Microsoft.AspNetCore.Mvc;
using MVC_WebApplication.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Configuration;

namespace MVC_WebApplication.Controllers
{
    public class Ctrl_Team : Controller
    {
        public SQL_Context ctx = new SQL_Context(@"server=localhost;uid=root;password=Gen$park0;database=genspark_proj");
        public IActionResult DisplayTeamInfo()
        {
            List<Model_Team> list = ctx.DisplayTeams();
            return View(list);
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
