﻿using Microsoft.AspNetCore.Mvc;

namespace MVC_WebApplication.Controllers
{
    public class Admin : Controller
    {
        [HttpPost]
        public IActionResult AddRole()
        {
            return View();
        }

        public IActionResult UpdateNews()
        {
            return View();
        }
    }
}
