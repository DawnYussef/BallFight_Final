﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MVC_WebApplication.Models;


namespace MVC_WebApplication.Controllers
{
    public class Crtl_CourtDisplay : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public ActionResult Create()
        {
            return View();
        }
    }
}
