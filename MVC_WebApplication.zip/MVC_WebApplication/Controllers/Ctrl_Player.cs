﻿using Microsoft.AspNetCore.Mvc;
using MVC_WebApplication.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Text.Encodings.Web;

namespace MVC_WebApplication.Controllers
{
    public class Ctrl_Player : Controller
    {
        public SQL_Context ctx = new SQL_Context(@"server=localhost;uid=root;password=Gen$park0;database=genspark_proj");
        public IActionResult DisplayStats()
        {
            List<Model_Player> list = ctx.DisplayPlayers();
            return View(list);
        }
        
        public string Encode_dataID(int id)
        {
            return HtmlEncoder.Default.Encode($"{id}");
        }
        public IActionResult DisplayRoster(string ID, string team_abr, string player_pos)
        {
            if(ID == "1")
            {
                team_abr = "LAL";
                //player_pos = "";
                List<Model_TeamRoster> list = ctx.TeamRoster_Compile(1, player_pos);
                return View(list);
            }

            else if(ID == "2")
            {
                team_abr = "GSW";
                //player_pos = "";
                List<Model_TeamRoster> list = ctx.TeamRoster_Compile(2, player_pos);
                return View(list);
            }

            //URL parameter(s).
            //init = Encode_dataID(team_id); 

            //int HtmlEncoder.Default.Encode(${team_id});
            //Acquire from user input; [TEST] team_id = 1, team_name = 'Lakers'
            
            
            return View();
        }

        [NonAction]
        public List<Model_Player> PlayerList()
        {
            return new List<Model_Player>
            {
                 new Model_Player //Default "null" PlayerData;
                 {
                     Player_id = 1,
                     Team_id = 0,
                     Player_num = 0,
                     Player_name = "Default",
                     Player_pos = "NA",
                     PTS = 0,
                     REB = 0,
                     AST = 0,
                     BLK = 0,
                     GP = 0,
                     FGM = 0, FGA = 0,
                     Three_PM = 0, Three_PA = 0,
                     FTM = 0, FTA = 0,
                     STL = 0,
                     PF = 0

                 },

                 new Model_Player //Default "null" PlayerData;
                 {
                     Player_id = 2,
                     Team_id = 0,
                     Player_num = 0,
                     Player_name = "Default",
                     Player_pos = "NA",
                     PTS = 0,
                     REB = 0,
                     AST = 0,
                     BLK = 0,
                     GP = 0,
                     FGM = 0, FGA = 0,
                     Three_PM = 0, Three_PA = 0,
                     FTM = 0, FTA = 0,
                     STL = 0,
                     PF = 0

                 },
            };
        }

        
        public ActionResult Index()
        {
            var players = from data in PlayerList()
                            orderby data.Player_id
                            select data;
            return View(players);
        }

        //MySQL Connection(s):
        public static string conSQL_Str = "server=localhost;database=genspark_proj;uid=root;port=3306;pwd=Gen$park0";
        MySqlConnection conSQL_init = new MySqlConnection(conSQL_Str);

        [HttpPost]
        public ContentResult Create_PlayerData()
        {
            string status = "";
            //using var conSQL_Player = new MySqlConnection(conSQL_Str);
            conSQL_init.Open();
            string create_Player = "CREATE TABLE if not exists PlayerData(player_id int auto_increment PRIMARY KEY, team_id int not null, player_num int, player_name varchar(100) not null, player_pos varchar(2), PTS int, REB int, AST int, BLK int, GP int, FGM int, FGA int, three_PM int, three_PA int, FTM int, FTA int, STL int, PF int); ";
            
            using var cmndSQL_Player = new MySqlCommand(create_Player, conSQL_init);
            cmndSQL_Player.ExecuteNonQuery();
            
            status = (cmndSQL_Player.ExecuteNonQuery() >= 1) ? "Record Success! - Database initialized" : "Unable to connect ...";
            status += "<br/>";
            conSQL_init.Close();
            
            return Content(status);
        }

        [HttpPost]
        public ContentResult Desc_PlayerData()
        {
            string status = "";
            conSQL_init.Open();
            string desc_Player = "SELECT * from PlayerData;";
            using var cmndSQL_Desc = new MySqlCommand(desc_Player, conSQL_init);
            MySqlDataReader qrd = cmndSQL_Desc.ExecuteReader();
            while (qrd.Read())
            {
                //Append to <table> in HTML
                status += qrd["Player_num"] + " * Player(Name): " + qrd["Player_name"] + " * Position: " + qrd["Player_pos"] 
                    + "\n * PTS(Points): " + qrd["PTS"] + " * REB(Rebounds): " + qrd["REB"]
                    + "\n * AST(Assists): " + qrd["AST"] + " * BLK(Blocks): " + qrd["BLK"] + qrd["GP"]
                    + "\n * 2PM(2-Points Made): " + qrd["FGM"] + " * 2PA(2-Points Attempted): " + qrd["FGA"]
                    + "\n * 3PM(3-Points Made): " + qrd["Three_PM"] + " * 3PA(3-Points Attempted): " + qrd["Three_PA"]
                    + "\n * FTM(Free-Throw Made): " + qrd["FTM"] + " * FTA(Free-Throw Attempted): " + qrd["FTA"]
                    + "\n * STL(Steals): " + qrd["STL"] + "* PF (Personal Fouls): " + qrd["PF"] + "<br/>";

            }
            
            return Content(status);
        }

        /* Reference for MySQL View Components:
        [HttpPost]
        public ContentResult {SQL-Command}_PlayerData()
        {
            string status = "";
            return Content(status);
        } 
         */
    }
}
