﻿using MVC_WebApplication.Models;
using Microsoft.AspNetCore.Mvc;

namespace MVC_WebApplication.Controllers
{
    public class Ctrl_User : Controller
    {

        public SQL_Context ctx = new SQL_Context(@"server=localhost;uid=root;password=Gen$park0;database=genspark_proj");
        public IActionResult Index()
        {
            List<Model_User> list = ctx.Admin_listUsers();
            return View(list);
        }

        
        public IActionResult Social()
        {
            return View();
        }
        
        /*public IActionResult DisplayRoster(string ID, string team_abr, string player_pos)
        {
            if(ID == "1")
            {
                team_abr = "LAL";
                //player_pos = "";
                List<Model_TeamRoster> list = ctx.TeamRoster_Compile(1, player_pos);
                return View(list);
            }

            else if(ID == "2")
            {
                team_abr = "GSW";
                //player_pos = "";
                List<Model_TeamRoster> list = ctx.TeamRoster_Compile(2, player_pos);
                return View(list);
            }

            //URL parameter(s).
            //init = Encode_dataID(team_id); 

            //int HtmlEncoder.Default.Encode(${team_id});
            //Acquire from user input; [TEST] team_id = 1, team_name = 'Lakers'
            
            
            return View();
        }*/

        public IActionResult DisplayComments([Bind(include: "User_id, Username")] Model_User user, [Bind(include:"Comments")] Model_Comment profile)
        {
            //Research - Stored value 'User_id' @ login.
            List<Model_Comment> list = ctx.AcctContent_Compile(user.User_id);
            if (ModelState.IsValid)
            {
                var join = user.User_id;
                var username = user.Username;
                var content = profile.Comments;

                list.Add(profile);
  
            }

            return View(list);
        }

        public IActionResult Register([Bind(include: "Username, Email, Password")] Model_User user)
        {
            if (ModelState.IsValid)
            {

                var username = user.Username;
                var email = user.Email;
                var password = user.Password;

                //if("ex" != null){} -- load Email? / Password? RequiredPage.
                if (ctx.User_Registration(username, email, password) == true)
                {
                    return RedirectToAction("Login", user);
                }
                else
                {
                    ViewBag.Message = String.Format("Unable to register - *fields incomplete");
                    RedirectToAction("Register", user);
                }
                //ctx.User_Registration(username, email, password);
                //return RedirectToAction("Register");
            }

            return View(user);
        }

        public IActionResult Delete()
        {
            return View();
        }

        public IActionResult Login([Bind(include: "Email, Password")] Model_User user)
        {
            var userLocal = HttpContext.Session.GetInt32("_userID");
            if (userLocal != null) return RedirectToAction("Index", "Home");

            if (user.Email != null && user.Password != null)
            {
                var email = user.Email;
                var password = user.Password;

                ViewBag.Message = null;

                var i = ctx.Login(email, password);

                if (i != null)
                {
                    HttpContext.Session.SetInt32("_userID", i.User_id);
                    return RedirectToAction("Index", "Home");
                }

                else
                {
                    ViewBag.Message = String.Format("Unable to verify username or password; please try again ...");
                    RedirectToAction("Login", user);
                    //TempData["msg"] = "<script>alert('FALSE');</script>";
                    //return View(user);
                }
            }

            return View(user);
        }
    }
}
